x=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
e=0
o=0
for i in x:
    if(i%2==0):
        e+=1
    else:
        o+=1

print("even count is", e)

print("odd count is", o)


