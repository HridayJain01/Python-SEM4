def tuples_to_lists(tuple_list):
    result=[]
    for t in tuple_list:
        nlist=list(t)
        result.append(nlist)
    return result

tuple_list1 = [(1, 2), (2, 3), (3, 4)]
tuple_list2 = [(1, 2), (2, 3, 5), (3, 4), (2, 3, 4, 2)]

print("Original list of tuples:", tuple_list1)
print("Convert the said list of tuples to a list of lists:", tuples_to_lists(tuple_list1))

print("Original list of tuples:", tuple_list2)
print("Convert the said list of tuples to a list of lists:", tuples_to_lists(tuple_list2))
