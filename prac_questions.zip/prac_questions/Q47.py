# get maximum and minimum values of didctionary

sample_dict = {
    "a": 10,
    "b": 20,
    "c": 5,
    "d": 37,
    "e": 40
}

max_value = max(sample_dict.values())

min_value = min(sample_dict.values())

print("Dictionary:", sample_dict)
print("Maximum value in dictionary:", max_value)
print("Minimum value in the dictionary:", min_value)
