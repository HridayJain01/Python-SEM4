def colorcheck(sc,x):
    for t in x:
        for  i in t:
         if sc==i:
            return True
         
    return False


x=(('Red', 'White', 'Blue'), ('Green', 'Pink', 'Purple'), ('Orange', 'Yellow', 'Lime'))
print(x)
sc=input("Enter color to be searched:")
print("The color you are looking for is:",colorcheck(sc,x))